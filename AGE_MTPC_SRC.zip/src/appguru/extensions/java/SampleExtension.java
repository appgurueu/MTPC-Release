package res.extensions.java;
//import appguru.info.Console;

public class SampleExtension {
    public static void main(String... args) {
        System.out.println("Hooray from Java!");
        //Console.successMessage("Hoorayy from Java");
    }
}
