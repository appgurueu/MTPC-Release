CONSOLE=luajava.bindClass("appguru.info.Console")
CONSOLE:successMessage(EXTENSION_PATH,"ME = LOADED!")
STATUS="COMPLETED RUN"
