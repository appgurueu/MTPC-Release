# `xy` Software for the Makeblock XY Plotter

## Installation

    brew install py2cairo
    pip install -r requirements.txt

You will probably need to set the `PORT` in device.py, as well as the `UP`
and `DOWN` pen positions:

https://github.com/fogleman/xy/blob/master/xy/device.py

## Examples

Several examples are in the root of the repository.
