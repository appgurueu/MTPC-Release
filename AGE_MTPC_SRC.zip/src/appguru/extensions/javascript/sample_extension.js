var Console=Java.type("appguru.info.Console");
Console.successMessage(EXTENSION_PATH,"I have been loaded. YAY!");
INTERVAL=500;
function SYNCHRONIZED() {
    Console.successMessage(EXTENSION_PATH,"I have been executed. YAY!");
}
STATUS="RUN COMPLETED";

