package appguru.timer;

abstract public interface TimeListener {
    abstract public void invoke(long arg);
}
