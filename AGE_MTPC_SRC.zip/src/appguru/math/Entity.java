package appguru.math;

public class Entity {
    public Entity() {
        super();
    }
}
