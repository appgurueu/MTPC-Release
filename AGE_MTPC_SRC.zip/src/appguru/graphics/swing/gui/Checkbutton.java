package appguru.graphics.swing.gui;

public class Checkbutton extends appguru.graphics.swing.gui.Component {
    public Checkbutton(appguru.graphics.swing.gui.BoundingBox a) {
        super(a);
    }
}
