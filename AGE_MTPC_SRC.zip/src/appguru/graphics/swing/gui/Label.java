package appguru.graphics.swing.gui;

public class Label {
    public Label() {
        super();
    }
}
