package appguru.graphics.swing.gui;

public class ContentPane extends appguru.graphics.swing.gui.BoundingBox {
    public java.util.ArrayList content;
    
    public ContentPane(appguru.graphics.swing.gui.BoundingBox a) {
        super(a);
    }
}
