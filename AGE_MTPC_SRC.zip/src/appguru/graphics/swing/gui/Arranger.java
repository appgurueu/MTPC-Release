package appguru.graphics.swing.gui;

public class Arranger {
    public Arranger() {
        super();
    }
    
    public static appguru.graphics.swing.gui.BoundingBox[] arrange(appguru.graphics.swing.gui.BoundingBox[] a) {
        return null;
    }
}
