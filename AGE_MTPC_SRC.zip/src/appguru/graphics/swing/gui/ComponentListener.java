package appguru.graphics.swing.gui;

abstract public interface ComponentListener {
    abstract public void valueChanged(Object arg);
    
    
    abstract public void stateChanged(byte arg);
}
