package appguru.graphics.swing;

public class BasicComboBox extends javax.swing.DefaultComboBoxModel {
    public BasicComboBox() {
        super();
    }
}
