package appguru.graphics.swing;

class SwingHelper$GlobalListener implements java.awt.event.ActionListener {
    public Object[] values;
    final appguru.graphics.swing.SwingHelper this$0;
    
    public SwingHelper$GlobalListener(appguru.graphics.swing.SwingHelper a, Object[] a0) {
                super();
        this.this$0 = a;
        this.values = a0;
    }
    
    public void actionPerformed(java.awt.event.ActionEvent a) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
