package appguru.graphics.ogl;

public class AdvancedMorphing {
    public com.jogamp.opengl.math.Matrix4[] morphings;
    public appguru.math.Vector4[] groups;
    
    public AdvancedMorphing(appguru.graphics.ogl.Mesh a, appguru.graphics.ogl.Mesh a0, appguru.math.Cube[] a1, appguru.math.Sphere[] a2) {
        super();
    }
}
