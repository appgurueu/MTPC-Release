package appguru.graphics.ogl;

public class Model extends appguru.graphics.ogl.Camera {
    public int mesh;
    public int material;
    
    public Model(int i, int i0) {
        super();
        this.mesh = i;
        this.material = i0;
    }
}
